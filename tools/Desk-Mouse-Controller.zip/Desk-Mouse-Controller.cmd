@echo off
setlocal
title Desk-Mouse-Controller
if not exist "%~dp0Desk-Mouse-Controller.ps1" (
  echo Desk-Mouse-Controller.ps1 is missing from this folder.
  echo Keep the CMD and PS1 files together.
  pause
  exit /b 2
)
start "" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Desk-Mouse-Controller.ps1"
exit
