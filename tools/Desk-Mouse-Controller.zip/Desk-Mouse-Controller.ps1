﻿param(
    [string]$Action = '',
    [string]$ConfirmationText = '',
    [switch]$DeleteSigning
)

# Automatically request administrator access when launched normally. This keeps
# the uninstaller usable by double-clicking either the CMD or this PS1 file.
$currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$currentPrincipal = [Security.Principal.WindowsPrincipal]::new($currentIdentity)
$isAdministrator = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdministrator) {
    $elevatedArgs = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
    if ($Action) { $elevatedArgs += ' -Action ' + $Action }
    if ($ConfirmationText) { $elevatedArgs += ' -ConfirmationText ' + $ConfirmationText }
    if ($DeleteSigning) { $elevatedArgs += ' -DeleteSigning' }
    $powershellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    try {
        Start-Process -FilePath $powershellExe -ArgumentList $elevatedArgs -Verb RunAs -WorkingDirectory (Split-Path -Parent $PSCommandPath) | Out-Null
    } catch { }
    exit
}

try {
    $Host.UI.RawUI.BackgroundColor = 'Black'
    $Host.UI.RawUI.ForegroundColor = 'Gray'
    Clear-Host
} catch { }

$ErrorActionPreference = 'Continue'
$script:AppName = 'Desk Mouse'
$script:AppGuid = '{8D5A432C-77C4-4F41-A1A4-B05B7F5BA8B5}_is1'
$script:ServiceName = 'DeskMousePreLogin'
$script:ReleaseAtomUrl = 'https://github.com/aljamesamir4090/DeskMouse-Releases/releases.atom'
$script:ReleaseDownloadRoot = 'https://github.com/aljamesamir4090/DeskMouse-Releases/releases/download'
$script:RemoteRelease = $null
$script:FirewallRuleNames = @(
    'Desk Mouse LAN Control',
    'Desk Mouse LAN Discovery',
    'Desk Mouse Pre-Login Host',
    'Desk Mouse Pre-Login Discovery'
)

function Write-Heading([string]$Text) {
    Write-Host ''
    Write-Host $Text -ForegroundColor Cyan
    Write-Host ('-' * [Math]::Min(72, $Text.Length)) -ForegroundColor DarkCyan
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-UninstallRecords {
    $roots = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall'
    )
    $records = @()
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($key in (Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
            $item = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
            $isKnownGuid = $key.PSChildName -eq $script:AppGuid
            $isExactProduct = [string]$item.DisplayName -eq $script:AppName
            $isLegacyProductKey = $key.PSChildName -eq $script:AppName
            if ($isKnownGuid -or $isExactProduct -or $isLegacyProductKey) {
                $records += [pscustomobject]@{
                    RegistryPath   = $key.Name
                    RegistryPsPath = $key.PSPath
                    KeyName        = $key.PSChildName
                    DisplayName    = [string]$item.DisplayName
                    DisplayVersion = [string]$item.DisplayVersion
                    InstallLocation= [string]$item.InstallLocation
                    UninstallString= [string]$item.UninstallString
                    Publisher      = [string]$item.Publisher
                }
            }
        }
    }
    return $records
}

function Get-RecordVersion($Record) {
    $raw = [string]$Record.DisplayVersion
    if ($raw -match '(?<!\d)(\d+\.\d+(?:\.\d+){0,2})(?!\d)') {
        try { return [version]$Matches[1] } catch { }
    }
    $exe = Join-Path ([string]$Record.InstallLocation) 'DeskMouseDesktop.exe'
    if (Test-Path -LiteralPath $exe -PathType Leaf) {
        $productVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo($exe).ProductVersion
        if ($productVersion -match '(?<!\d)(\d+\.\d+(?:\.\d+){0,2})(?!\d)') {
            try { return [version]$Matches[1] } catch { }
        }
    }
    return $null
}

function Get-KnownInstalledVersionRecords {
    $result = @()
    foreach ($record in (Get-UninstallRecords)) {
        $version = Get-RecordVersion $record
        if ($null -ne $version) {
            $result += [pscustomobject]@{ Record = $record; Version = $version }
        }
    }
    return $result
}

function Get-LatestInstalledVersion {
    $versions = @(Get-KnownInstalledVersionRecords | ForEach-Object { $_.Version } | Sort-Object -Unique -Descending)
    if ($versions.Count) { return $versions[0] }
    return $null
}

function Get-GitHubLatestRelease {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $response = Invoke-WebRequest -Uri $script:ReleaseAtomUrl -Headers @{ 'User-Agent' = 'DeskMouseUninstaller'; 'Accept' = 'application/atom+xml' } -UseBasicParsing -TimeoutSec 25
        [xml]$feed = $response.Content
        $namespaces = New-Object System.Xml.XmlNamespaceManager($feed.NameTable)
        $namespaces.AddNamespace('atom', 'http://www.w3.org/2005/Atom')
        $entries = $feed.SelectNodes('/atom:feed/atom:entry', $namespaces)
        foreach ($entry in $entries) {
            $releaseLink = $entry.SelectSingleNode('atom:link[@rel="alternate"]', $namespaces)
            $tagMatch = [regex]::Match([string]$releaseLink.href, '/releases/tag/(v?\d+\.\d+\.\d+)$')
            if (-not $tagMatch.Success) { continue }
            $tag = $tagMatch.Groups[1].Value
            $versionText = $tag -replace '^v', ''
            try { $version = [version]$versionText } catch { continue }
            $contentNode = $entry.SelectSingleNode('atom:content', $namespaces)
            $releaseBody = [Net.WebUtility]::HtmlDecode([string]$contentNode.InnerText)
            $assetName = "DeskMouse-Setup-v$versionText-x64.exe"
            if ($releaseBody -notmatch [regex]::Escape($assetName)) { continue }
            $hashMatch = [regex]::Match($releaseBody, '(?i)Windows:\s*([0-9a-f]{64})')
            if (-not $hashMatch.Success) { continue }
            return [pscustomobject]@{
                Version = $version
                Tag = $tag
                InstallerName = $assetName
                InstallerUrl = "$($script:ReleaseDownloadRoot)/$tag/$assetName"
                Sha256 = $hashMatch.Groups[1].Value.ToUpperInvariant()
                ReleaseUrl = [string]$releaseLink.href
            }
        }
        throw 'The public release feed had no stable Windows installer with a SHA-256 entry.'
    } catch {
        Write-Host ('Could not check the public Desk Mouse releases: ' + $_.Exception.Message) -ForegroundColor Yellow
        return $null
    }
}

function Write-UpdateProgress([string]$Label, [long]$BytesReceived, [long]$TotalBytes, [int]$Frame, [switch]$SpinnerOnly) {
    $spinners = @('|', '/', '-', '\')
    $line = '  ' + $spinners[$Frame % $spinners.Count] + ' ' + $Label
    if (-not $SpinnerOnly -and $TotalBytes -gt 0) {
        $percent = [Math]::Min(100, [int](100 * $BytesReceived / $TotalBytes))
        $barWidth = 24
        $filled = [Math]::Min($barWidth, [int]($barWidth * $percent / 100))
        $bar = ('=' * $filled).PadRight($barWidth, ' ')
        $line += (' [{0}] {1,3}%  {2:N1}/{3:N1} MB' -f $bar, $percent, ($BytesReceived / 1MB), ($TotalBytes / 1MB))
    } elseif (-not $SpinnerOnly) {
        $line += ('  {0:N1} MB' -f ($BytesReceived / 1MB))
    }
    try {
        $width = [Math]::Max(40, [Console]::WindowWidth - 1)
        if ($line.Length -gt $width) { $line = $line.Substring(0, $width) }
        $progressColor = if ($TotalBytes -gt 0 -and $BytesReceived -ge $TotalBytes) { 'Green' } else { 'Cyan' }
        Write-Host ("`r" + $line.PadRight($width)) -ForegroundColor $progressColor -NoNewline
    } catch {
        Write-Host $line
    }
}

function Invoke-VerifiedInstallerDownload($Release, [string]$Destination) {
    $request = [Net.HttpWebRequest]::Create([Uri]$Release.InstallerUrl)
    $request.UserAgent = 'DeskMouseUninstaller'
    $request.AllowAutoRedirect = $true
    $request.Timeout = 180000
    $request.ReadWriteTimeout = 180000
    $response = $null
    $inputStream = $null
    $outputStream = $null
    $received = [long]0
    $total = [long]0
    $frame = 0
    $lastDraw = [Diagnostics.Stopwatch]::StartNew()
    try {
        $response = $request.GetResponse()
        $total = [long]$response.ContentLength
        $inputStream = $response.GetResponseStream()
        $outputStream = [IO.File]::Open($Destination, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $buffer = New-Object byte[] 65536
        Write-UpdateProgress -Label 'Downloading...' -BytesReceived 0 -TotalBytes $total -Frame $frame
        while (($count = $inputStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            $outputStream.Write($buffer, 0, $count)
            $received += $count
            if ($lastDraw.ElapsedMilliseconds -ge 100) {
                Write-UpdateProgress -Label 'Downloading...' -BytesReceived $received -TotalBytes $total -Frame $frame
                $frame++
                $lastDraw.Restart()
            }
        }
        $outputStream.Flush()
        Write-UpdateProgress -Label 'Downloading...' -BytesReceived $received -TotalBytes $total -Frame $frame
        Write-Host ''
    } catch {
        Write-Host ''
        Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
        throw
    } finally {
        if ($outputStream) { $outputStream.Dispose() }
        if ($inputStream) { $inputStream.Dispose() }
        if ($response) { $response.Dispose() }
    }
}

function Invoke-UpdateNow {
    Write-Heading 'Checking Desk Mouse updates'
    $release = Get-GitHubLatestRelease
    if (-not $release) {
        Write-Host 'Update check failed. Check your internet connection and try again.' -ForegroundColor Yellow
        return $false
    }
    $installed = Get-LatestInstalledVersion
    if ($null -ne $installed -and $release.Version -le $installed) {
        Write-Host ("You're up to date. Installed V $installed; public release V $($release.Version).") -ForegroundColor Green
        return $false
    }

    $tempInstaller = Join-Path $env:TEMP ("DeskMouse-Update-v{0}-{1}.exe" -f $release.Version, [guid]::NewGuid().ToString('N'))
    Write-Host ("Latest public version: V $($release.Version)") -ForegroundColor Cyan
    try {
        Invoke-VerifiedInstallerDownload -Release $release -Destination $tempInstaller
        $actualHash = (Get-FileHash -LiteralPath $tempInstaller -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actualHash -ne $release.Sha256) {
            Remove-Item -LiteralPath $tempInstaller -Force -ErrorAction SilentlyContinue
            Write-Host 'The downloaded installer could not be verified against the official release. It was removed; update stopped.' -ForegroundColor Red
            return $false
        }
        Write-Host 'Download verified.' -ForegroundColor Green
        Write-Host 'Installing... replacing existing Desk Mouse files and removing obsolete app files.' -ForegroundColor Cyan
        $installer = Start-Process -FilePath $tempInstaller -ArgumentList '/SP- /SILENT /NORESTART /CLOSEAPPLICATIONS' -PassThru
        $frame = 0
        while (-not $installer.HasExited) {
            Write-UpdateProgress -Label 'Installing...' -BytesReceived 0 -TotalBytes 0 -Frame $frame -SpinnerOnly
            $frame++
            if ($installer.WaitForExit(120)) { break }
        }
        $installer.Refresh()
        Write-Host ''
        if ($installer.ExitCode -ne 0) {
            Write-Host ("Installer returned exit code $($installer.ExitCode). The downloaded installer was kept at: $tempInstaller") -ForegroundColor Yellow
            return $false
        }
        $installedAfter = Get-LatestInstalledVersion
        if ($null -ne $installedAfter -and $installedAfter -ge $release.Version) {
            Remove-Item -LiteralPath $tempInstaller -Force -ErrorAction SilentlyContinue
            Write-Host ("Update complete. Desk Mouse V $installedAfter is installed. Temporary installer removed.") -ForegroundColor Green
            return $true
        } else {
            Write-Host ("Installer finished, but V $($release.Version) could not be confirmed in Windows Installed apps. Installer kept at: $tempInstaller") -ForegroundColor Yellow
            return $false
        }
    } catch {
        Write-Host ('Update failed: ' + $_.Exception.Message) -ForegroundColor Red
        if (Test-Path -LiteralPath $tempInstaller) { Write-Host ('Downloaded file kept for review: ' + $tempInstaller) -ForegroundColor Yellow }
        return $false
    }
}

function Start-DeskMouseApp {
    foreach ($directory in (Get-InstallDirectories)) {
        $appExe = Join-Path $directory 'DeskMouseDesktop.exe'
        if (Test-Path -LiteralPath $appExe -PathType Leaf) {
            try {
                Start-Process -FilePath $appExe -WorkingDirectory $directory | Out-Null
                Write-Host 'Desk Mouse opened.' -ForegroundColor Green
                return $true
            } catch {
                Write-Host ('Desk Mouse could not be opened: ' + $_.Exception.Message) -ForegroundColor Yellow
                return $false
            }
        }
    }
    Write-Host 'Update completed, but DeskMouseDesktop.exe was not found in the installed app folder.' -ForegroundColor Yellow
    return $false
}

function Get-InstallDirectories {
    $paths = [System.Collections.Generic.List[string]]::new()
    foreach ($record in (Get-UninstallRecords)) {
        if (-not [string]::IsNullOrWhiteSpace($record.InstallLocation)) {
            $paths.Add($record.InstallLocation.Trim().TrimEnd('\'))
        }
    }
    $roots = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, (Join-Path $env:LOCALAPPDATA 'Programs'))
    foreach ($root in ($roots | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)) {
        foreach ($leaf in @('Desk Mouse', 'DeskMouse')) {
            $paths.Add((Join-Path $root $leaf))
        }
    }
    return $paths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
}

function Get-ProductUninstaller {
    foreach ($record in (Get-UninstallRecords)) {
        $raw = $record.UninstallString
        if ([string]::IsNullOrWhiteSpace($raw)) { continue }
        if ($raw -match '^\s*"([^"]+)"\s*(.*)$') {
            $exe = $Matches[1]
            $args = $Matches[2]
        } elseif ($raw -match '^\s*(\S+)(?:\s+(.*))?$') {
            $exe = $Matches[1]
            $args = $Matches[2]
        } else { continue }
        if ((Test-Path -LiteralPath $exe -PathType Leaf) -and
            ($exe -match '(?i)unins\d*\.exe$|DeskMouseUninstaller\.exe$')) {
            return [pscustomobject]@{ FilePath = $exe; Arguments = [string]$args }
        }
    }
    foreach ($directory in (Get-InstallDirectories)) {
        foreach ($name in @('unins000.exe', 'DeskMouseUninstaller.exe')) {
            $exe = Join-Path $directory $name
            if (Test-Path -LiteralPath $exe -PathType Leaf) {
                return [pscustomobject]@{ FilePath = $exe; Arguments = '' }
            }
        }
    }
    return $null
}

function Get-TempMatches {
    $roots = @($env:TEMP, [IO.Path]::GetTempPath(), (Join-Path $env:SystemRoot 'Temp')) |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
    $items = @()
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
        $items += Get-ChildItem -LiteralPath $root -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '^DeskMouseRemove-[0-9a-f]{32}\.ps1$' }
    }
    return $items | Sort-Object FullName -Unique
}

function Get-PrefetchMatches {
    $root = Join-Path $env:SystemRoot 'Prefetch'
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { return @() }
    return @(Get-ChildItem -LiteralPath $root -File -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^DESKMOUSE(?:DESKTOP|PRELOGINSERVICE|PRELOGINAGENT).*\.PF$' })
}

function Get-FirewallMatches {
    $rules = @(Get-NetFirewallRule -ErrorAction SilentlyContinue)
    $matches = @()
    foreach ($rule in $rules) {
        if ($script:FirewallRuleNames -contains $rule.DisplayName) {
            $matches += $rule
            continue
        }
        # A few older Windows-generated rules used the executable name. Remove them
        # only when their program path points at this product's installed EXE.
        if ($rule.DisplayName -ieq 'desk mouse.exe') {
            $appFilter = Get-NetFirewallApplicationFilter -AssociatedNetFirewallRule $rule -ErrorAction SilentlyContinue
            if ($appFilter.Program -match '(?i)(^|\\)DeskMouseDesktop\.exe$') { $matches += $rule }
        }
    }
    return $matches
}

function Get-PathInventory {
    $paths = [System.Collections.Generic.List[string]]::new()
    foreach ($path in (Get-InstallDirectories)) { $paths.Add($path) }
    foreach ($path in @(
        (Join-Path $env:LOCALAPPDATA 'Desk Mouse'),
        (Join-Path $env:LOCALAPPDATA 'DeskMouse'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Desk Mouse'),
        (Join-Path $env:APPDATA 'Desk Mouse'),
        (Join-Path $env:APPDATA 'DeskMouse'),
        (Join-Path $env:ProgramData 'Desk Mouse'),
        (Join-Path $env:ProgramData 'DeskMouse'),
        (Join-Path ([Environment]::GetFolderPath('Programs')) 'Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('Programs')) 'Desk Mouse\Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'Desk Mouse\Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) 'Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Desk Mouse.lnk')
    )) { $paths.Add($path) }
    return $paths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
}

function Show-CheckReport {
    Write-Heading 'Read-only scan'
    Write-Host 'No files or settings will be changed.' -ForegroundColor Green

    $allPaths = @(Get-PathInventory)
    $foundPaths = @($allPaths | Where-Object { Test-Path -LiteralPath $_ })
    Write-Host "`nLocations found ($($foundPaths.Count)) :"
    if ($foundPaths.Count) { $foundPaths | ForEach-Object { Write-Host ('  ' + $_) } }
    else { Write-Host '  None' }
    $missingCount = $allPaths.Count - $foundPaths.Count
    if ($missingCount -gt 0) { Write-Host ("  Other checked locations: $missingCount not found") -ForegroundColor DarkGray }

    $temp = @(Get-TempMatches)
    $prefetch = @(Get-PrefetchMatches)
    if ($temp.Count -or $prefetch.Count) {
        Write-Host "`nTemp / Prefetch matches:"
        $temp | ForEach-Object { Write-Host ('  ' + $_.FullName) }
        $prefetch | ForEach-Object { Write-Host ('  ' + $_.FullName) }
    } else { Write-Host "`nTemp / Prefetch: no matching files" }

    $uninstall = @(Get-UninstallRecords)
    $run = Get-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'Desk Mouse' -ErrorAction SilentlyContinue
    $service = Get-CimInstance Win32_Service -Filter "Name='$script:ServiceName'" -ErrorAction SilentlyContinue
    Write-Host "`nWindows integration:"
    if ($uninstall.Count) { Write-Host ("  Uninstall registration: found ($($uninstall.Count))") }
    if ($null -ne $run) { Write-Host '  Start with Windows: enabled' }
    if ($service) { Write-Host ("  Pre-login service: $($service.State), $($service.StartMode)") }

    $firewall = @(Get-FirewallMatches)
    if ($firewall.Count) {
        $ruleSummary = $firewall | Group-Object DisplayName | ForEach-Object {
            if ($_.Count -gt 1) { "$($_.Name) ($($_.Count))" } else { $_.Name }
        }
        Write-Host ('  Firewall rules: ' + ($ruleSummary -join ', '))
    }

    $signing = Join-Path $env:LOCALAPPDATA 'Desk Mouse\PublisherSigning'
    if (Test-Path -LiteralPath $signing) {
        Write-Host ("`nSigning files found; kept by default: $signing") -ForegroundColor Yellow
    }
}

function Test-ProductInstallDirectory([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path -PathType Container)) { return $false }
    try { $full = [IO.Path]::GetFullPath($Path).TrimEnd('\') } catch { return $false }
    $blocked = @(
        [IO.Path]::GetPathRoot($full).TrimEnd('\'),
        $env:SystemRoot,
        $env:ProgramFiles,
        ${env:ProgramFiles(x86)},
        $env:LOCALAPPDATA,
        $env:APPDATA,
        $env:ProgramData,
        $env:USERPROFILE
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { ([string]$_).TrimEnd('\') }
    if ($blocked -contains $full) { return $false }
    $markers = @(
        'DeskMouseDesktop.exe',
        'DeskMouseUninstaller.exe',
        'unins000.exe',
        'prelogin\DeskMousePreLoginService.exe'
    )
    return [bool]($markers | Where-Object { Test-Path -LiteralPath (Join-Path $full $_) -PathType Leaf } | Select-Object -First 1)
}

function Remove-ItemSafely([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    try {
        Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
        Write-Host ('  removed: ' + $Path) -ForegroundColor Green
    } catch {
        Write-Host ('  could not remove: ' + $Path + ' - ' + $_.Exception.Message) -ForegroundColor Yellow
    }
}

function Remove-DeskMouseStartupAndRegistry {
    Remove-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'Desk Mouse' -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath 'HKCU:\Software\Desk Mouse' -Recurse -Force -ErrorAction SilentlyContinue
    foreach ($record in (Get-UninstallRecords)) {
        Remove-Item -LiteralPath $record.RegistryPsPath -Recurse -Force -ErrorAction SilentlyContinue
    }
    Remove-Item -LiteralPath 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Desk Mouse' -Recurse -Force -ErrorAction SilentlyContinue
    if (@(Get-UninstallRecords).Count -eq 0) {
        Write-Host '  removed Desk Mouse entry from Windows Installed apps.' -ForegroundColor Green
    } else {
        Write-Host '  some Desk Mouse entries remain in Windows Installed apps.' -ForegroundColor Yellow
    }
}

function Stop-DeskMouseService {
    $service = Get-CimInstance Win32_Service -Filter "Name='$script:ServiceName'" -ErrorAction SilentlyContinue
    if (-not $service) { return }
    $servicePath = [string]$service.PathName
    if ($servicePath -notmatch '(?i)DeskMousePreLoginService\.exe') {
        Write-Host '  skipped service with unexpected executable path.' -ForegroundColor Yellow
        return
    }
    & "$env:SystemRoot\System32\sc.exe" stop $script:ServiceName 2>$null | Out-Null
    Start-Sleep -Milliseconds 900
    & "$env:SystemRoot\System32\sc.exe" delete $script:ServiceName 2>$null | Out-Null
    Write-Host '  stopped/deleted DeskMousePreLogin service.' -ForegroundColor Green
}

function Remove-DeskMouseFirewallRules {
    foreach ($rule in (Get-FirewallMatches)) {
        try {
            Remove-NetFirewallRule -InputObject $rule -ErrorAction Stop
            Write-Host ('  removed firewall rule: ' + $rule.DisplayName) -ForegroundColor Green
        } catch {
            Write-Host ('  could not remove firewall rule: ' + $rule.DisplayName) -ForegroundColor Yellow
        }
    }
}

function Remove-DeskMouseShortcuts {
    $shortcuts = @(
        (Join-Path ([Environment]::GetFolderPath('Programs')) 'Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('Programs')) 'Desk Mouse\Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'Desk Mouse\Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) 'Desk Mouse.lnk'),
        (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Desk Mouse.lnk')
    ) | Select-Object -Unique
    foreach ($path in $shortcuts) { Remove-ItemSafely $path }
    $remaining = @($shortcuts | Where-Object { Test-Path -LiteralPath $_ })
    if (-not $remaining.Count) { Write-Host '  removed Desk Mouse Desktop and Start menu shortcuts.' -ForegroundColor Green }
    else { Write-Host '  some Desk Mouse shortcuts remain.' -ForegroundColor Yellow }
}

function Stop-DeskMouseProcesses([string[]]$InstallDirectories) {
    foreach ($process in (Get-Process -Name DeskMouseDesktop -ErrorAction SilentlyContinue)) {
        $path = $null
        try { $path = $process.MainModule.FileName } catch { }
        $isProduct = $false
        foreach ($directory in $InstallDirectories) {
            if ($path -and $path.StartsWith($directory.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { $isProduct = $true }
        }
        if (-not $isProduct) { continue }
        try {
            $process.CloseMainWindow() | Out-Null
            if (-not $process.WaitForExit(2500)) { $process.Kill(); $process.WaitForExit(3000) }
            Write-Host '  closed Desk Mouse process.' -ForegroundColor Green
        } catch { Write-Host '  could not close one Desk Mouse process.' -ForegroundColor Yellow }
    }
}

function Remove-TempAndPrefetchMatches {
    foreach ($item in (Get-TempMatches)) { Remove-ItemSafely $item.FullName }
    foreach ($item in (Get-PrefetchMatches)) { Remove-ItemSafely $item.FullName }
}

function Remove-LocalData([bool]$RemoveSigningMaterial) {
    $local = Join-Path $env:LOCALAPPDATA 'Desk Mouse'
    if (Test-Path -LiteralPath $local -PathType Container) {
        $signing = Join-Path $local 'PublisherSigning'
        if ((Test-Path -LiteralPath $signing) -and -not $RemoveSigningMaterial) {
            Get-ChildItem -LiteralPath $local -Force -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -ne $signing } | ForEach-Object { Remove-ItemSafely $_.FullName }
            Write-Host ('  preserved publisher signing material: ' + $signing) -ForegroundColor Yellow
        } else { Remove-ItemSafely $local }
    }
    foreach ($path in @(
        (Join-Path $env:LOCALAPPDATA 'DeskMouse'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Desk Mouse'),
        (Join-Path $env:APPDATA 'Desk Mouse'),
        (Join-Path $env:APPDATA 'DeskMouse'),
        (Join-Path $env:ProgramData 'Desk Mouse'),
        (Join-Path $env:ProgramData 'DeskMouse')
    )) { Remove-ItemSafely $path }
}

function Invoke-OfficialUninstaller {
    $uninstaller = Get-ProductUninstaller
    if (-not $uninstaller) {
        Write-Host 'No registered Desk Mouse uninstaller was found.' -ForegroundColor Yellow
        return $false
    }
    Write-Host ('Starting: ' + $uninstaller.FilePath)
    try {
        $process = Start-Process -FilePath $uninstaller.FilePath -ArgumentList $uninstaller.Arguments -Wait -PassThru
        Start-Sleep -Seconds 2
        $stillRegistered = @(Get-UninstallRecords | Where-Object { Test-Path -LiteralPath $_.InstallLocation })
        if ($stillRegistered.Count) {
            Write-Host 'The app still appears installed (the official uninstaller may have been cancelled).' -ForegroundColor Yellow
            return $false
        }
        Write-Host 'Official app uninstall finished.' -ForegroundColor Green
        return $true
    } catch {
        Write-Host ('Could not start the official uninstaller: ' + $_.Exception.Message) -ForegroundColor Red
        return $false
    }
}

function Invoke-ManualCleanup([bool]$RemoveSigningMaterial) {
    $installDirectories = @(Get-InstallDirectories)
    Stop-DeskMouseProcesses -InstallDirectories $installDirectories
    Stop-DeskMouseService
    Remove-DeskMouseFirewallRules
    Remove-DeskMouseStartupAndRegistry
    Remove-DeskMouseShortcuts
    Remove-LocalData -RemoveSigningMaterial $RemoveSigningMaterial
    Remove-TempAndPrefetchMatches
    foreach ($directory in $installDirectories) {
        if (Test-ProductInstallDirectory $directory) { Remove-ItemSafely $directory }
    }
}

function Invoke-ElevatedAction([string]$SelectedAction, [bool]$RemoveSigningMaterial) {
    $scriptPath = $PSCommandPath
    $arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $scriptPath + '" -Action ' + $SelectedAction + ' -ConfirmationText DELETE'
    if ($RemoveSigningMaterial) { $arguments += ' -DeleteSigning' }
    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    try {
        Start-Process -FilePath $powershell -ArgumentList $arguments -Verb RunAs -Wait
        return $true
    } catch {
        Write-Host 'Administrator approval was cancelled; no cleanup was run.' -ForegroundColor Yellow
        return $false
    }
}

function Invoke-SelectedAction([string]$SelectedAction, [bool]$RemoveSigningMaterial) {
    if (-not (Test-Administrator)) {
        Write-Host 'Administrator access is needed for uninstall/cleanup. Windows will show its UAC prompt.' -ForegroundColor Yellow
        [void](Invoke-ElevatedAction -SelectedAction $SelectedAction -RemoveSigningMaterial $RemoveSigningMaterial)
        return
    }
    switch ($SelectedAction) {
        '2' { [void](Invoke-OfficialUninstaller) }
        '3' { Invoke-ManualCleanup -RemoveSigningMaterial $RemoveSigningMaterial }
        '4' {
            $completed = Invoke-OfficialUninstaller
            if ($completed) { Invoke-ManualCleanup -RemoveSigningMaterial $RemoveSigningMaterial }
            else { Write-Host 'Residual cleanup stopped because app uninstall did not complete.' -ForegroundColor Yellow }
        }
    }
}

function Invoke-ConfirmedAction([string]$SelectedAction, [bool]$RemoveSigningMaterial) {
    if ($ConfirmationText -cne 'DELETE') {
        Write-Host 'Safety check failed: no DELETE confirmation was received.' -ForegroundColor Red
        return
    }
    Invoke-SelectedAction -SelectedAction $SelectedAction -RemoveSigningMaterial $RemoveSigningMaterial
}

if ($Action) {
    if ($Action -eq '5') {
        if ($ConfirmationText -cne 'CHECK') {
            Write-Host 'Safety check failed: type CHECK to run the read-only scan.' -ForegroundColor Red
            Read-Host "`nPress Enter to close"
            exit
        }
        Show-CheckReport
        Read-Host "`nPress Enter to close"
        exit
    }
    if ($Action -notin @('2','3','4')) {
        Write-Host 'Unknown action. Nothing was changed.' -ForegroundColor Red
        Read-Host "`nPress Enter to close"
        exit
    }
    if ($Action -in @('2','3','4') -and $ConfirmationText -cne 'DELETE') {
        Write-Host 'Safety check failed: type DELETE before removing Desk Mouse.' -ForegroundColor Red
        Read-Host "`nPress Enter to close"
        exit
    }
    Invoke-ConfirmedAction -SelectedAction $Action -RemoveSigningMaterial ([bool]$DeleteSigning)
    Read-Host "`nPress Enter to close"
    exit
}

$script:RemoteRelease = Get-GitHubLatestRelease

while ($true) {
    Clear-Host
    Write-Host 'Welcome to Desk Mouse:' -ForegroundColor Cyan
    Write-Host ''
    $menuInstalled = @(Get-KnownInstalledVersionRecords)
    $menuVersions = @($menuInstalled | ForEach-Object { $_.Version } | Sort-Object -Unique -Descending)
    if ($menuVersions.Count) {
        Write-Host ("Detected Desk Mouse Version: V {0}" -f $menuVersions[0])
    } else {
        Write-Host 'Detected Desk Mouse Version: not installed' -ForegroundColor DarkGray
    }
    if ($script:RemoteRelease) {
        if (-not $menuVersions.Count) {
            Write-Host ''
            Write-Host ("Desk Mouse is ready to download. Press 1 to download V {0}." -f $script:RemoteRelease.Version) -ForegroundColor Yellow
        } elseif ($script:RemoteRelease.Version -gt $menuVersions[0]) {
            Write-Host ''
            Write-Host ("New version available! Press 1 to update to V {0}." -f $script:RemoteRelease.Version) -ForegroundColor Yellow
        }
    } else { Write-Host 'Could not check for a new version (offline).' -ForegroundColor Yellow }
    Write-Host ''
    Write-Host 'Choose what you want:'
    Write-Host ''
    if (-not $script:RemoteRelease) {
        Write-Host '1. Check for updates'
    } elseif (-not $menuVersions.Count) {
        Write-Host ("1. Download now to V {0}" -f $script:RemoteRelease.Version)
    } elseif ($script:RemoteRelease.Version -gt $menuVersions[0]) {
        Write-Host ("1. Update now to V {0}" -f $script:RemoteRelease.Version)
    } else {
        Write-Host '1. Check for updates'
    }
    Write-Host '2. Uninstall Desk Mouse app'
    Write-Host '3. Remove all Desk Mouse files and folders'
    Write-Host '4. Both 2+3 (Recommended)'
    Write-Host '5. Check all file locations only (does not delete anything)'
    Write-Host ''
    Write-Host '0. Exit'
    Write-Host ''
    $choice = Read-Host 'Enter a number'
    if ($choice -eq '0') { break }
    if ($choice -notin @('1','2','3','4','5')) {
        Write-Host 'Choose 0, 1, 2, 3, 4, or 5.' -ForegroundColor Yellow
        Start-Sleep -Seconds 2
        continue
    }
    if ($choice -eq '1') {
        $updateComplete = Invoke-UpdateNow
        if ($updateComplete) {
            Read-Host "`nPress Enter to close PowerShell and open Desk Mouse"
            [void](Start-DeskMouseApp)
            exit
        }
        $script:RemoteRelease = Get-GitHubLatestRelease
        Read-Host "`nPress Enter to return to the menu"
        continue
    }
    if ($choice -eq '5') {
        $check = Read-Host 'Read-only check selected. Type CHECK to continue'
        if ($check -cne 'CHECK') {
            Write-Host 'CHECK did not match. Nothing was changed.' -ForegroundColor Yellow
            Start-Sleep -Seconds 2
            continue
        }
        Show-CheckReport
        Read-Host "`nPress Enter to return to the menu"
        continue
    }
    Write-Heading 'Review before uninstalling'
    switch ($choice) {
        '2' { Write-Host 'This runs the registered Desk Mouse uninstaller. User settings may remain.' }
        '3' { Write-Host 'This removes the detected Desk Mouse install, app data, shortcuts, service, firewall rules, and app registry entries.' }
        '4' { Write-Host 'This uninstalls Desk Mouse, then removes remaining Desk Mouse data and registrations.' }
    }
    Write-Host 'Shared parent folders will not be deleted; only exact Desk Mouse items are targeted.'
    $removeSigningMaterial = $false
    $signing = Join-Path $env:LOCALAPPDATA 'Desk Mouse\PublisherSigning'
    if ($choice -in @('3','4') -and (Test-Path -LiteralPath $signing)) {
        Write-Host ''
        Write-Host 'Publisher signing files were found. They may be needed for future release signing.' -ForegroundColor Yellow
        $signChoice = Read-Host 'Type DELETE SIGNING to remove them too; press Enter to preserve them'
        $removeSigningMaterial = $signChoice -ceq 'DELETE SIGNING'
    }
    Write-Host ''
    $confirmation = Read-Host 'To proceed with this uninstall choice, type DELETE'
    if ($confirmation -cne 'DELETE') {
        Write-Host 'Confirmation did not match. Nothing was changed.' -ForegroundColor Yellow
        Start-Sleep -Seconds 2
        continue
    }
    $ConfirmationText = $confirmation
    Invoke-ConfirmedAction -SelectedAction $choice -RemoveSigningMaterial $removeSigningMaterial
    Read-Host "`nPress Enter to return to the menu"
}
